-- Cleaning the data 

-- Firstly we need to clean the Customer_orders table
drop table if exists customer_orders1;
CREATE TABLE customer_orders1 AS (SELECT order_id,
    customer_id,
    roll_id,
    not_include_items,
    extra_items_included,
    order_date FROM
    customer_orders);
    
UPDATE customer_orders1 
SET 
    not_include_items = CASE
        WHEN not_include_items = 'null' THEN NULL
        WHEN not_include_items = ' ' THEN NULL
        ELSE not_include_items
    END,
    extra_items_included = CASE
        WHEN extra_items_included = 'null' THEN NULL
        WHEN extra_items_included = ' ' THEN NULL
        WHEN extra_items_included = 'NaN' THEN NULL
        ELSE extra_items_included
    END;
     -- end of cleaning process of customer_orders table
     
     
    -- cleaning the customer_orders table
    drop table if exists driver_order1;
    create table driver_order1 as
    (select order_id, driver_id, pickup_time, 
    case
    when distance like '%km' then trim('km' from distance)
    else distance
    end as distance,
    case
    when duration like '%minutes' then trim('minutes' from duration)
    when duration like '%minute' then trim('minute' from duration)
	when duration like '%mins' then trim('mins' from duration)
    when duration like '%km' then trim('km' from duration)
    when duration like ' ' then NULL
    else duration
    end as duration,
    cancellation from driver_order);
    update driver_order1 
    set 
    cancellation = case
    cancellation when "null" then null
				 when "nan" then null
                 when " " then null
                 else cancellation 
                 end;
	select * from driver_order1;
    select * from customer_orders1;
    -- end of cleaning process of driver_order table
    
    update driver_order1 
    set pickup_time = "2021-01-11 18:50:20" where order_id = 10;
    