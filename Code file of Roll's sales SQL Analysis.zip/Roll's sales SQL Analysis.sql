-- Pizza Metrics Analysis --

-- 1. How many rolls were ordered?
SELECT 
    COUNT(order_id) AS total_rolls_ordered
FROM
    customer_orders;

-- 2. How many unique customer orders were made?
SELECT 
    COUNT(DISTINCT order_id) AS unique_orders
FROM
    customer_orders;

-- 3. How many successful orders were delivered by each delivery person?
SELECT 
    driver_id, COUNT(order_id) AS succesful_orders
FROM
    driver_order1
WHERE
    duration IS NOT NULL
GROUP BY driver_id;

-- 4. How many each type of roll was delivered?
SELECT 
    roll_id, COUNT(c.order_id) AS total_orders
FROM
    driver_order1 AS d
        JOIN
    customer_orders AS c ON d.order_id = c.order_id
WHERE
    duration IS NOT NULL
GROUP BY roll_id;

-- 5. How many veg and non veg rolls were ordered by each customer
SELECT 
    a.*, r.roll_name
FROM
    (SELECT 
        customer_id, roll_id, COUNT(roll_id) AS count
    FROM
        customer_orders1
    GROUP BY customer_id , roll_id
    ORDER BY customer_id) a
        INNER JOIN
    rolls r ON a.roll_id = r.roll_id;

-- 6. What was the maximum number of rolls delivered in a single order?
SELECT 
    d.order_id, COUNT(c.roll_id) AS total_rolls
FROM
    driver_order AS d
        JOIN
    customer_orders AS c ON d.order_id = c.order_id
WHERE
    duration IS NOT NULL
GROUP BY d.order_id
ORDER BY total_rolls DESC
LIMIT 1;

-- 7. for each customer, how many delivered rolls had at least one change and how many had no change?
SELECT 
    c.customer_id,
    SUM(CASE
        WHEN
            (not_include_items IS NOT NULL
                AND extra_items_included IS NULL)
                OR (not_include_items IS NULL
                AND extra_items_included IS NOT NULL)
        THEN
            1
        ELSE 0
    END) AS AtLeastNoChange,
    SUM(CASE
        WHEN
            (not_include_items IS NULL
                AND extra_items_included IS NULL)
        THEN
            1
        ELSE 0
    END) AS NoChange
FROM
    customer_orders1 AS c
        JOIN
    driver_order1 AS d ON c.order_id = d.order_id
WHERE
    d.duration IS NOT NULL
GROUP BY customer_id;

-- 8. How many rolls were delivered that had both exclusions and extras?
SELECT 
    c.customer_id,
    SUM(CASE
        WHEN
            (not_include_items IS NOT NULL
                AND extra_items_included IS NOT NULL)
        THEN
            1
        ELSE 0
    END) AS ExtrasAndExclusions
FROM
    customer_orders1 AS c
        JOIN
    driver_order1 AS d ON c.order_id = d.order_id
WHERE
    d.duration IS NOT NULL
GROUP BY customer_id
ORDER BY ExtrasAndExclusions DESC;

-- 9. What was the total volume of rolls ordered for each hour of the day?

SELECT 
    EXTRACT(HOUR FROM order_date) AS HourlyData,
    COUNT(order_id) AS TotalOrders
FROM
    customer_orders1
GROUP BY HourlyData
ORDER BY TotalOrders DESC;

-- 10. What was the volume of orders for each day of the week?

SELECT 
    DAYNAME(order_date) AS days, COUNT(order_id) AS TotalOrders
FROM
    customer_orders1
GROUP BY days
ORDER BY days;

-- Driver and Customer Experience

-- 1. What was the average time in minutes it took for each driver to arrive to pick up the order?

select driver_id, avg(timediff) 
from
(select driver_id,timestampdiff(minute, order_date, pickup_time) as timediff from
customer_orders1 as c join driver_order1 as d 
on c.order_id = d.order_id
where duration is not null) as subquery
group by driver_id;

-- 2. Is there any relationship between the number of rolls and how long the order takes to prepare?
SELECT 
    subquery.order_id, 
    COUNT(subquery.order_id) AS order_count, 
    SUM(subquery.timetaken) AS total_timetaken
FROM
    (SELECT 
        c.order_id, 
        TIMESTAMPDIFF(MINUTE, c.order_date, d.pickup_time) AS timetaken
     FROM 
        customer_orders1 AS c 
     JOIN 
        driver_order1 AS d
     ON 
        c.order_id = d.order_id
     WHERE 
        d.duration IS NOT NULL
    ) AS subquery
GROUP BY 
    subquery.order_id;


-- 3. What was the average distance traveled for each customer?

SELECT 
    customer_id, ROUND(AVG(distance), 2) AvgDistanceTravelled
FROM
    customer_orders1 AS c
        JOIN
    driver_order1 AS d ON c.order_id = d.order_id
WHERE
    d.duration IS NOT NULL
GROUP BY customer_id;

-- 4. What was the difference between the longest and shortest delivery times for all orders?

SELECT 
    (MAX(subquery2.ordertime) - MIN(subquery2.ordertime)) AS TimeDiffMin
FROM
    (SELECT 
        subquery1.order_id,
            TIMESTAMPDIFF(MINUTE, subquery1.order_date, subquery1.pickup_time) AS ordertime
    FROM
        (SELECT 
        c.order_id, order_date, pickup_time
    FROM
        customer_orders1 AS c
    JOIN driver_order1 AS d ON c.order_id = d.order_id
    WHERE
        d.duration IS NOT NULL) AS subquery1) AS subquery2;

-- 5. What was the average speed for each driver for each delivery and do you notice any trend for these values?

SELECT 
    *,
    ROUND((subquery1.distance * 60 / subquery1.duration),
            2) AS speedkmh
FROM
    (SELECT 
        c.order_id, driver_id, distance, duration
    FROM
        customer_orders1 AS c
    JOIN driver_order1 AS d ON c.order_id = d.order_id
    WHERE
        duration IS NOT NULL) AS subquery1;

-- from the results we can analyze that there is no trend but average speed(KMpH) of each driver is as follows for delivering the orders
-- driverId 1 = 47.06
-- driverId 2 = 51.78
-- driverId 3 = 40 

-- 6.  What is the successful delivery percentage for each driver?
SELECT 
    *,
    ROUND(((subquery1.OrdersDelivered * 100) / TotalOrders),
            2) AS SuccDelPer
FROM
    (SELECT driver_id,
            SUM(CASE WHEN
                    cancellation = 'Cancellation'
                        OR cancellation = 'Customer Cancellation'
                THEN 1
                ELSE 1
            END) AS TotalOrders,
            SUM(CASE WHEN
                    cancellation = 'Customer Cancellation'
                        OR cancellation = 'Cancellation'
                THEN 0
                ELSE 1
            END) AS OrdersDelivered
    FROM
        driver_order1
    GROUP BY driver_id) AS subquery1;

-- Ingredient Optimisation

-- 7. What are the standard ingredients for each roll?

-- to get the standard ingridents for each roll we have to clean the rolls_recipies table first

drop table if exists rolls_recipies1;
CREATE TABLE rolls_recipies1 (
    roll_id INT,
    ingredients_id INT
);
insert into rolls_recipies1(roll_id, ingredients_id) values
(1,1),(1,2),(1,3),(1,4),(1,5),(1,6),(1,8),(1,10),
(2,4),(2,6),(2,7),(2,9),(2,11),(2,12);

SELECT 
    roll_id, GROUP_CONCAT(ingredients_name) as all_ingredients
FROM
    rolls_recipies1 AS r
        INNER JOIN
    ingredients AS i ON i.ingredients_id = r.ingredients_id
GROUP BY roll_id;

-- 9. Generate an order item for each record in the customers_orders table in the format of one of the following:
       -- Meat Lovers
       -- Meat Lovers - Exclude Beef
       -- Meat Lovers - Extra Bacon
       -- Meat Lovers - Exclude Cheese, Bacon - Extra Mushroom, Peppers
       -- veg lovers
     
			drop table if exists roll_customizations;
			CREATE TABLE roll_customizations (
				roll_id INT,
				exclusions VARCHAR(255),
				extras VARCHAR(255),
				order_item_name VARCHAR(255)
				);
				INSERT INTO roll_customizations (roll_id, exclusions, extras, order_item_name) VALUES
				(1, NULL, NULL, 'Meat Lovers'),
				(2, NULL, NULL, 'Veg Lovers'),
				(2, '4', NULL, 'Veg Lovers - Exclude Cheese'),
				(1, '4', NULL, 'Meat Lovers - Exclude Cheese'),
				(1, '3', NULL, 'Meat Lovers - Exclude Beef'),
				(1, NULL, '1', 'Meat Lovers - Extra Bacon'),
				(1, '1,4', '6,9', 'Meat Lovers - Exclude Cheese, Bacon - Extra Mushroom, Peppers'),
				(1, '2,6', '1,4', 'Meat Lovers - Exclude BBQ Sauce, Mushroom - Extra Bacon, Cheese'),
				(1, '4', '1,5', 'Meat Lovers - Exclude Cheese - Extra Bacon, Chicken');

				SELECT 
					c.order_id,
					c.roll_id,
					c.customer_id,
					c.not_include_items,
					c.extra_items_included,
					r.roll_name,
					rc.order_item_name AS order_item
				FROM
					customer_orders1 AS c
						INNER JOIN
					rolls AS r ON r.roll_id = c.roll_id
						LEFT JOIN
					roll_customizations AS rc ON c.roll_id = rc.roll_id
						AND (rc.exclusions = c.not_include_items
						OR rc.exclusions IS NULL
						AND c.not_include_items IS NULL)
						AND (rc.extras = c.extra_items_included
						OR rc.extras IS NULL
						AND c.extra_items_included IS NULL);
					
-- 8. If a Meat Lovers pizza costs $12 and Vegetarian costs $10 and there were no charges for changes,
--    how much money has Pizza Runner made so far if there are no delivery fees?
    
    select sum(case
    when c.roll_id= 1 then 12
    else 10 
    end) as TotalAmount
    from driver_order as d inner join
    customer_orders as c
    on c.order_id = d.order_id
    where d.duration is not null;